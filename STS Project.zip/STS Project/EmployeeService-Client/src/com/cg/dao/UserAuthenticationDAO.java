package com.cg.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cg.bo.UserAuthenticationBO;
/*
 * @ Author Ujjval.Kumar
 */
@Repository
public class UserAuthenticationDAO {
	private static final String LOGIN_QUERY="SELECT COUNT(*) FROM LOGIN WHERE USERNAME=? AND PASSWORD=?";
	@Autowired
	private JdbcTemplate jt;
	
	public int authenticateUser(UserAuthenticationBO bo) {
		 return jt.queryForObject(LOGIN_QUERY, Integer.class, bo.getUsername(),bo.getPassword());
	}

}
