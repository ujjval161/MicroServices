package com.cg.service;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import com.cg.dto.UserAuthenticationDTO;
import com.cg.model.Employee;

public interface EmployeeService {
	
	public int validateUser(UserAuthenticationDTO userBean);
	public ResponseEntity<Employee> findEmpbyID(int id) throws RestClientException, IOException;
}
