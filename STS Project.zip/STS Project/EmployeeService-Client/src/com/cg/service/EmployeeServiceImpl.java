package com.cg.service;


import java.io.IOException;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cg.bo.UserAuthenticationBO;
import com.cg.dao.UserAuthenticationDAO;
import com.cg.dto.UserAuthenticationDTO;
import com.cg.model.Employee;


/*
 * @ Author Ujjval.Kumar
 */
@Service("empService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private UserAuthenticationDAO dao;
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	public int validateUser(UserAuthenticationDTO userBean) {
		UserAuthenticationBO bo=null;
		//convert dto to bo
		bo=new UserAuthenticationBO();
		BeanUtils.copyProperties(userBean, bo);
		//call dao class method for authentication
		return dao.authenticateUser(bo);
	}

	@Override
	public ResponseEntity<Employee> findEmpbyID(int id) throws RestClientException, IOException {
		List<ServiceInstance> instances=discoveryClient.getInstances("employee-producer");
		ServiceInstance serviceInstance=instances.get(0);
		
        String baseUrl=serviceInstance.getUri().toString();
		
		baseUrl=baseUrl+"/api/employee";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders(),String.class);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println(response.getBody());
	
		return null;
	}
	
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}

	

}
