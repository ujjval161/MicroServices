package com.cg.model;

import java.util.Date;

import org.hibernate.validator.constraints.NotBlank;


public class Employee {

	
	private Long id;

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", dept=" + dept + ", doj=" + doj + "]";
	}

	@NotBlank
	private String name;

	@NotBlank
	private String dept;


	private Date doj;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

}
