package com.cg.controller;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.UserAuthenticationDTO;
import com.cg.model.UserAuthentication;
import com.cg.service.EmployeeService;
/*
 * @ Author Ujjval.Kumar
 */
@Controller
public class MultiPurposeController {
	@Autowired
	private EmployeeService service;
	
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
    public String init(Model model) {
        model.addAttribute("msg", "Please Enter Your Login Details");
        return "home";
    }
	
	
	@RequestMapping(value = "/login",method = RequestMethod.POST)
    public String submit(Model model, @ModelAttribute("loginBean") UserAuthentication loginBean) {
		UserAuthenticationDTO userdto=null;
		int result=0;
        if (loginBean != null && loginBean.getUsername() != null & loginBean.getPassword() != null) {
    		//convert command object into userDTO object
    		userdto=new UserAuthenticationDTO();
    		BeanUtils.copyProperties(loginBean, userdto);
    		//call business method to validate user
    		result=service.validateUser(userdto);
    		if(result==1) {
    			model.addAttribute("msg", "WELCOME " + loginBean.getUsername().toUpperCase());
                return "success";
    		}
    		
    		else {
                model.addAttribute("error", "Invalid Details");
                return "home";
            }
        }
        else {
        	model.addAttribute("error", "Enter Login Details.");
            return "home";
        }
    }
	
	@RequestMapping(value = "/findSingleEmployee", method = RequestMethod.GET)
    public String findSingleEmployee(Model model) {
        model.addAttribute("msg", "Please Enter Employee ID");
        return "findSingleEmployee";
    }
	
	@RequestMapping(value = "/findSingleEmployee", method = RequestMethod.POST)
    public String findSingleEmployeePostBack(Model model,@RequestParam int empId) {
        model.addAttribute("msg", "Please Enter Your Login Details");
        return "findSingleEmployee";
    }

}
