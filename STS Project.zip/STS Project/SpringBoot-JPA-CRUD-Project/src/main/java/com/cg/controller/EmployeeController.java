package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Employee;
import com.cg.repository.EmployeeRepository;

/*
 * @ Author Ujjval.Kumar
 */
@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	@PostMapping("/saveEmployee")
	public Employee createEmployee(@Valid @RequestBody Employee employee) {
	    return employeeRepository.save(employee);
	}
	
	
	// Get a Single Employee
	@GetMapping("/find/{id}")
	public ResponseEntity<Employee> getEmpById(@PathVariable(value = "id") Long empId) {
	    Employee employee = employeeRepository.findOne(empId);
	    if(employee == null) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok().body(employee);
	}
	
	// Get All Employee
	@GetMapping("/findAll")
	public List<Employee> getAllEmployees() {
	    return employeeRepository.findAll();
	}
	
	
	// Update a Employee
	@PutMapping("/employee/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Long empId, 
	                                       @Valid @RequestBody Employee empDetails) {
	    Employee emp = employeeRepository.findOne(empId);
	    if(emp == null) {
	        return ResponseEntity.notFound().build();
	    }
	    emp.setName(empDetails.getName());
	    emp.setDept(empDetails.getDept());
	    emp.setDoj(empDetails.getDoj());


	    Employee updatedEmployee = employeeRepository.save(emp);
	    return ResponseEntity.ok(updatedEmployee);
	}
	
	
	// Delete a Note
	@DeleteMapping("/employee/{id}")
	public ResponseEntity<Employee> deleteEmployee(@PathVariable(value = "id") Long empId) {
	    Employee emp = employeeRepository.findOne(empId);
	    if(emp == null) {
	        return ResponseEntity.notFound().build();
	    }

	    employeeRepository.delete(emp);
	    return ResponseEntity.ok().build();
	}

}
