package com.cg.handlar;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.cg.dto.EmployeeDTO;

@Component
public class ExcelView extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		 
		List<EmployeeDTO> list=(List<EmployeeDTO>) model.get("list");
		HSSFSheet sheet = workbook.createSheet("Employee Report");
		
		HSSFRow header = sheet.createRow(0);
		  header.createCell(0).setCellValue("Employee Id");
		  header.createCell(1).setCellValue("Name");
		  header.createCell(2).setCellValue("Salary");
		  header.createCell(3).setCellValue("Joining_Date");
		  header.createCell(4).setCellValue("Status");

		  int counter = 1;
		  for (EmployeeDTO e : list) {
		   HSSFRow row = sheet.createRow(counter++);
		   row.createCell(0).setCellValue(e.getEmpid());
		   row.createCell(1).setCellValue(e.getEmpname());
		   row.createCell(2).setCellValue(e.getEmpsalary());
		   row.createCell(3).setCellValue(e.getDoj().toString());
		   row.createCell(4).setCellValue(e.getStatus());
		  }
	}

}
