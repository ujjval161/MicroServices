package com.cg.dao;

import java.util.List;

import com.cg.bo.EmployeeBO;
import com.cg.bo.UserBO;

public interface UserListDAO {
	public int validateUser(UserBO bo);
	public List<EmployeeBO> EmployeeDetails();
	public EmployeeBO getEmployeeByNo(int no);
	public int UpdateEmployeeDetails(EmployeeBO bo);
	public int insertEmployee(EmployeeBO bo);
	public int deleteEmployee(int no);
	public int fetchEmployeeNo();

}
