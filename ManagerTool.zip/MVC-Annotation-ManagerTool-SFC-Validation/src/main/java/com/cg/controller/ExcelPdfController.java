package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.EmployeeDTO;
import com.cg.service.UserService;

@Controller("exController")
public class ExcelPdfController {
	@Autowired
	UserService service;
	
	@RequestMapping(value = "/generate/excel.htm", method = RequestMethod.GET)
	 ModelAndView generateExcel(HttpServletRequest request,
	            HttpServletResponse response) throws Exception {
		ModelAndView mav=null;
		List<EmployeeDTO> listdto=null;
	  System.out.println("Calling generateExcel()...");
	  
	  listdto=service.getEmpList();
	  mav=new ModelAndView();
	  mav.setViewName("excelView");
	  mav.addObject("list", listdto);
	  
	  return mav;
	}

}
