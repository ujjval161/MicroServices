package com.cg.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.command.EmployeeCommand;
import com.cg.command.UserCommand;
import com.cg.dto.EmployeeDTO;
import com.cg.dto.UserDTO;
import com.cg.service.UserService;

@Controller
public class LoginController {

	@Autowired(required = true)
	private UserService service;

	// handling initial phase request
	@RequestMapping(value = "/login.htm")
	public String process_initial_Phase(Map<String, Object> map,
			@ModelAttribute("userCmd") UserCommand cmd) {
		// return logical view name
		return "login";
	}

	// handling post back request
	@RequestMapping(value = "/login.htm", method = RequestMethod.POST)
	public ModelAndView process_post_back(Map<String, Object> map,
			@Valid @ModelAttribute("userCmd") UserCommand cmd,
			BindingResult errors) {
		UserDTO dto = null;
		List<EmployeeDTO> empdto = null;
		ModelAndView mav = null;

		int result;
		// Convert command object into UserDTO object
		dto = new UserDTO();
		BeanUtils.copyProperties(cmd, dto);
		//java.sql.Date formDate = new java.sql.Date(cmd.getDoj().getTime());
		//System.out.println(formDate + "  " + formDate.getClass());
		// Use service
		result = service.authenticateUser(dto);
		// System.out.println(result);
		// keep result in map as model attribute and value
		if (result == 0) {
			mav = new ModelAndView();
			mav.setViewName("login");
			mav.addObject("result", "!!Invalid Credentials Try Again!!");
			return mav;
		} else if (result != 0 && cmd.getRole().equalsIgnoreCase("M")) {

			empdto = service.getEmpList();
			mav = new ModelAndView();
			mav.setViewName("empList");
			mav.addObject("empList", empdto);
			return mav;

		} else if (cmd.getRole().equals("E")) {
			empdto = service.getEmpList();
			mav = new ModelAndView();
			mav.setViewName("employeeList");
			mav.addObject("empList", empdto);
			return mav;
		} else
			return new ModelAndView();

	}// process_post_back(-,-,-,-)

	// Below code is alternate to referenceData() method of XML based Spring MVC
	// Simple form controller

	@ModelAttribute("dmnList")
	public List<String> populateDomain() {
		List<String> domains = null;
		domains = new ArrayList<>();
		domains.add("Manager");
		domains.add("Employee");
		return domains;
	}// populateDomain()

	/*
	 * Built in property editors can able to convert form given String value to
	 * required command class property. But there is some cases where custom
	 * property editors cannot convert form value to appropriate type. ex-if we
	 * want to store date value in indian style like(dd-MM-yyyy) In such case
	 * below given annotation based method is great .
	 */

	@InitBinder
	public void myInitBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = null;
		sdf = new SimpleDateFormat("dd-MM-yyyy");
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}// myInitBinder(-)

	@RequestMapping(value = "/edit.htm")
	public String process_initial_Phase_edit(Map<String, Object> map,
			HttpServletRequest request,
			@ModelAttribute("userCmd") EmployeeCommand cmd) {
		int sno = 0;
		EmployeeDTO dto = null;
		ModelAndView mav=null;
		// read sno
		sno = Integer.parseInt(request.getParameter("empid"));
		// Use service class
		dto = new EmployeeDTO();
		dto = service.fetchEmployeeByNo(sno);
		BeanUtils.copyProperties(dto, cmd);
		mav=new ModelAndView();
		mav.addObject("cmd", cmd);
		return "edit";
	}

	@RequestMapping(value = "/edit.htm", method = RequestMethod.POST)
	public ModelAndView process_post_back_edit(Map<String, Object> map,
			HttpServletRequest request,
			@ModelAttribute("userCmd") EmployeeCommand cmd) {
		
		String result = null;
		EmployeeDTO dto = null;
		ModelAndView mav = null;

		dto = new EmployeeDTO();
		BeanUtils.copyProperties(cmd, dto);

		result = service.updateEmployee(dto);
		mav = new ModelAndView();
		mav.setViewName("edit_result");
		mav.addObject("edit_result", result);
		return mav;

	}

	/*
	 * @RequestMapping(value = "/delete.htm") public ModelAndView
	 * process_initial_Phase_delete(Map<String, Object> map, HttpServletRequest
	 * request,
	 * 
	 * @ModelAttribute("userCmd") EmployeeCommand cmd) { int sno = 0;
	 * EmployeeDTO dto = null; ModelAndView mav=null; // Use service class dto =
	 * new EmployeeDTO(); dto = service.fetchEmployeeByNo(sno);
	 * BeanUtils.copyProperties(dto, cmd); mav=new ModelAndView();
	 * mav.setViewName("delete"); mav.addObject("dto", dto); return mav; }
	 */

	@RequestMapping(value = "/delete.htm", method = RequestMethod.GET)
	public ModelAndView process_post_back_delete(HttpServletRequest request) {
		ModelAndView mav = null;
		String result = null;
		Integer empid = 0;
		// type casting
		empid = Integer.parseInt(request.getParameter("empid"));
		// use service
		result = service.eraseEmployeeDetails(empid);
		// create and return mav object
		mav = new ModelAndView();
		mav.setViewName("delete_result");
		mav.addObject("delete_employee", result);
		return mav;
	}

	@RequestMapping(value = "/employeeList.htm", method = RequestMethod.GET)
	public ModelAndView process_Employee_list(Map<String, Object> map,
			HttpServletRequest request) {
		List<EmployeeDTO> listDTO = null;
		ModelAndView mav = null;
		// Use service
		listDTO = service.getEmpList();
		// create and return ModelAndView object
		mav = new ModelAndView();
		mav.setViewName("employeeList");
		mav.addObject("empList", listDTO);
		return mav;

	}

	@RequestMapping(value = "/empList.htm", method = RequestMethod.GET)
	public ModelAndView process_Employee_list_for_employee(
			Map<String, Object> map, HttpServletRequest request) {
		List<EmployeeDTO> listDTO = null;
		ModelAndView mav = null;
		// Use service
		listDTO = service.getEmpList();
		// create and return ModelAndView object
		mav = new ModelAndView();
		mav.setViewName("empList");
		mav.addObject("empList", listDTO);
		return mav;

	}

	// handling initial phase request for registering new employee

	@RequestMapping(value = "/register.htm")
	public String process_initial_Phase_registration(Map<String, Object> map,
			@ModelAttribute("userCmd") EmployeeCommand cmd) {
		// return logical view
		cmd.setEmpid(service.getEmployeeNumberFormSequence());
		return "register_employee";
	}

	// handling initial phase request for registering new employee

	@RequestMapping(value = "/register.htm", method = RequestMethod.POST)
	public ModelAndView process_postback_registration(
			HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("userCmd") EmployeeCommand cmd) {

		ModelAndView mav = null;
		String result = null;
		EmployeeDTO dto = null;

		// convert command object to dto object
		dto = new EmployeeDTO();
		BeanUtils.copyProperties(cmd, dto);
		// System.out.println(cmd.getEmpname()+"  "+cmd.getEmpid()+"  "+cmd.getDoj());
		result = service.registerEmployee(dto);
		// create and return mav object
		mav = new ModelAndView();
		mav.setViewName("register_result");
		mav.addObject("register_employee", result);
		return mav;
	}
	
	
	
	@RequestMapping(value = "/edit_status.htm")
	public String process_initial_Phase_edit_status(Map<String, Object> map,
			HttpServletRequest request,
			@ModelAttribute("userCmd") EmployeeCommand cmd) {
		int sno = 0;
		EmployeeDTO dto = null;
		ModelAndView mav=null;
		// read sno
		sno = Integer.parseInt(request.getParameter("empid"));
		// Use service class
		dto = new EmployeeDTO();
		dto = service.fetchEmployeeByNo(sno);
		BeanUtils.copyProperties(dto, cmd);
		mav=new ModelAndView();
		mav.addObject("cmd", cmd);
		return "edit_status";
	}

	@RequestMapping(value = "/edit_status.htm", method = RequestMethod.POST)
	public ModelAndView process_post_back_edit_status(Map<String, Object> map,
			HttpServletRequest request,
			@ModelAttribute("userCmd") EmployeeCommand cmd) {
		
		String result = null;
		EmployeeDTO dto = null;
		ModelAndView mav = null;

		dto = new EmployeeDTO();
		BeanUtils.copyProperties(cmd, dto);

		result = service.updateEmployee(dto);
		mav = new ModelAndView();
		mav.setViewName("edit_status_result");
		mav.addObject("edit_result", result);
		return mav;

	}
	
	/*@RequestMapping(value = "/generate/excel.htm", method = RequestMethod.GET)
	 ModelAndView generateExcel(HttpServletRequest request,
	            HttpServletResponse response) throws Exception {
		ModelAndView mav=null;
		List<EmployeeDTO> listdto=null;
	  System.out.println("Calling generateExcel()...");
	  
	  listdto=service.getEmpList();
	  mav=new ModelAndView();
	  mav.setViewName("excelView");
	  mav.addObject("list", listdto);
	  
	  return mav;
	}*/

}
