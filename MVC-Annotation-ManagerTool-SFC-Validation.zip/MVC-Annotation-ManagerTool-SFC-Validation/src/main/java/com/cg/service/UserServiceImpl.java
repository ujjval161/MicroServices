package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bo.EmployeeBO;
import com.cg.bo.UserBO;
import com.cg.dao.UserListDAO;
import com.cg.dto.EmployeeDTO;
import com.cg.dto.UserDTO;

@Service
public class UserServiceImpl implements UserService {

	@Autowired(required=true)
	private UserListDAO dao;
	
	@Override
	public int authenticateUser(UserDTO dto) {
		List<EmployeeDTO> empdto=new ArrayList<EmployeeDTO>();
		int count=0;
		UserBO bo=null;
		//Convert UserDTO to UserBO
		bo=new UserBO();
		BeanUtils.copyProperties(dto, bo);
		return count=dao.validateUser(bo);
		
	}
	@Override
	public List<EmployeeDTO> getEmpList() {
		List<EmployeeBO> listbo;
		List<EmployeeDTO> listdto=null;
		EmployeeDTO empdto=null;
		
		listdto=new ArrayList<EmployeeDTO>();
		listbo=dao.EmployeeDetails();
		//System.out.println("Service-list size"+listbo.size());
		for(EmployeeBO bo:listbo){
			empdto=new EmployeeDTO();
			BeanUtils.copyProperties(bo, empdto);
			listdto.add(empdto);
		}
		return listdto;
	}
	@Override
	public EmployeeDTO fetchEmployeeByNo(int no) {
		EmployeeDTO dto=null;
		EmployeeBO bo=null;
		// Use DAO
		bo=dao.getEmployeeByNo(no);
		//convert bo to dto
		dto=new EmployeeDTO();
		BeanUtils.copyProperties(bo, dto);
		return dto;
	}
	@Override
	public String updateEmployee(EmployeeDTO dto) {
		int count=0;
		EmployeeBO bo=null;
		// Convert Student dto to Student bo
		bo=new EmployeeBO();
		BeanUtils.copyProperties(dto, bo);
		//use dao to update student details
		count=dao.UpdateEmployeeDetails(bo);
		if(count==0) {
			return "Employee Record Cannot Be Updated..";
		}
		else {
			return "Employee Record Updated Successfully..";
		}
	}
	@Override
	public String registerEmployee(EmployeeDTO dto) {
		int count=0;
		EmployeeBO bo=null;
		// Convert Student dto to Student bo
		bo=new EmployeeBO();
		BeanUtils.copyProperties(dto, bo);
		//use dao to update student details
		count=dao.insertEmployee(bo);
		if(count==0) {
			return "Employee Record Cannot Be Inserted..!!Try Again";
		}
		else {
			return "Employee Record Inserted Successfully..@@";
		}
	}
	@Override
	public String eraseEmployeeDetails(int no) {
		int count=0;
		//use dao
		count=dao.deleteEmployee(no);
		if(count==0)
			return "Employee Number:"+no+" not is deleted!!Try Again";
		else
			return "Employee Number:"+no+"  is deleted successfully@@";
	}
	@Override
	public int getEmployeeNumberFormSequence() {
		int sno=0;
		// Use dao
		sno=dao.fetchEmployeeNo();
		return sno;
	}

}
