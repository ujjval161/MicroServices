package com.cg.service;

import java.util.List;

import com.cg.dto.EmployeeDTO;
import com.cg.dto.UserDTO;

public interface UserService {
	public int authenticateUser(UserDTO dto);
	public List<EmployeeDTO> getEmpList();
	public EmployeeDTO fetchEmployeeByNo(int no);
	public String updateEmployee(EmployeeDTO dto);
	public String registerEmployee(EmployeeDTO dto);
	public String eraseEmployeeDetails(int no);
	public int getEmployeeNumberFormSequence();

}
