package com.cg.dto;

import java.io.Serializable;
import java.sql.Date;

public class EmployeeDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6286195496992687413L;
	private Integer empid;
	private String empname;
	private String status;
	private Integer empsalary;
	
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(Integer empsalary) {
		this.empsalary = empsalary;
	}
}
