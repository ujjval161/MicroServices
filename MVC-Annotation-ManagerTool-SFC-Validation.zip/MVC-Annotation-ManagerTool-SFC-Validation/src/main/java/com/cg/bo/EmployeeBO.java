package com.cg.bo;

import java.io.Serializable;
import java.sql.Date;

public class EmployeeBO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6664746686889978662L;
	private Integer empid;
	private String empname;
	private String status;
	private Integer empsalary;
	
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(Integer empsalary) {
		this.empsalary = empsalary;
	}
}
