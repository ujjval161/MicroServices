package com.cg.bo;

import java.io.Serializable;
import java.util.Date;

public class EmployeeBO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6664746686889978662L;
	private Integer empid;
	private Integer empsalary;
	private String empname;
	private Date doj;
	private String status;
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public Integer getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(Integer empsalary) {
		this.empsalary = empsalary;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
