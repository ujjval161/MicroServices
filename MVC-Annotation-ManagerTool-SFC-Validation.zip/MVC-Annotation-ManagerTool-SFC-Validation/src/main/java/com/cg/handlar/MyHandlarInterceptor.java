package com.cg.handlar;

import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class MyHandlarInterceptor extends HandlerInterceptorAdapter {
	
	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler)
			throws Exception {
		// 
		int sToken=0,cToken=0;
		HttpSession ses=null;
		RequestDispatcher rd=null;
		if(req.getMethod().equalsIgnoreCase("GET")) {
			if(req.getSession()==null)
				ses=req.getSession(true);
			else
				ses=req.getSession(false);
			//set server side token
			ses.setAttribute("sToken", new Random().nextInt(10000));
			return true;
		}//if
		else {//if request is post back or form is submitted or refresh button clicked
			ses=req.getSession(false);
			//read both server and client side tokens
			sToken=(Integer)ses.getAttribute("sToken");
			cToken=Integer.parseInt(req.getParameter("cToken"));
			
			//compare both tokens if both are equal then allow to handler method
			if(sToken==cToken) {
				//change server side token 
				ses.setAttribute("sToken", new Random().nextInt(10000));
				return true;
			}//if
			
			else {
				rd=req.getRequestDispatcher("dbl_post.jsp");
				rd.forward(req, res);
				return false;
			}// nested else
		}//else
	}//method
}//class
