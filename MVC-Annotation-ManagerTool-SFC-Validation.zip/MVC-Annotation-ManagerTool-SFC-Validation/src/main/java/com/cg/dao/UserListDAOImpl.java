package com.cg.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.cg.bo.EmployeeBO;
import com.cg.bo.UserBO;

@Repository
public class UserListDAOImpl implements UserListDAO {
	//prepare query
	private static final String GET_ALL_EMPLOYEE="SELECT EMPID,EMPNAME,EMPSALARY,DOJ,STATUS FROM EMPLOYEE";
	private static final String GET_EMPLOYEE_BY_NO="SELECT EMPID,EMPNAME,EMPSALARY,DOJ,STATUS FROM STUDENT WHERE SNO=?";
	private static final String UPDATE_EMPLOYEE="UPDATE EMPLOYEE SET EMPNAME=?,EMPSALARY=?,STATUS=? WHERE EMPID=?";
	private static final String INSERT_QRY="INSERT INTO EMPLOYEE VALUES(?,?,?,?,?)";
	private static final String DELETE_QRY="DELETE FROM EMPLOYEE WHERE EMPID=?";
	private static final String FIND_EMPNO="SELECT STUDENT_SNO.nextVal FROM DUAL";
	private static final String AUTH_QRY="SELECT COUNT(*) FROM USERLIST WHERE USERNAME=? AND PASSWORD=?";
	@Autowired
	private JdbcTemplate jt;
	
	@Override
	public int validateUser(UserBO bo) {
		int count=0;
		//Use jt
		count=jt.queryForObject(AUTH_QRY, Integer.class, bo.getUsername(),bo.getPassword());
		return count;
	}

	@Override
	public List<EmployeeBO> EmployeeDetails() {
	
				List<EmployeeBO> listbo=null;
				listbo=jt.query(GET_ALL_EMPLOYEE, new MyResultSetExtractor());
				return listbo;
	}

	@Override
	public EmployeeBO getEmployeeByNo(int no) {
		EmployeeBO bo=null;
		// Use jt to interect with db and get result in the form of bo object
		bo=jt.queryForObject(GET_EMPLOYEE_BY_NO, (rs,index)->{
			EmployeeBO ebo=new EmployeeBO();
			ebo.setEmpid(rs.getInt(1));
			ebo.setEmpname(rs.getString(2));
			ebo.setEmpsalary(rs.getInt(3));
			ebo.setStatus(rs.getString(4));
			return ebo;
		}, no);
		return bo;
	}

	@Override
	public int UpdateEmployeeDetails(EmployeeBO bo) {
		int count=0;
		// Use jt to update Student details
		count=jt.update(UPDATE_EMPLOYEE,bo.getEmpname(),bo.getEmpsalary(),bo.getStatus(),bo.getEmpid());
		return count;
	}

	@Override
	public int insertEmployee(EmployeeBO bo) {
		int count=0;
		Long millis=System.currentTimeMillis();
		java.sql.Date date=new Date(millis);
		count=jt.update(INSERT_QRY, bo.getEmpid(),bo.getEmpname(),bo.getEmpsalary(),date,bo.getStatus());
		return count;
	}

	@Override
	public int deleteEmployee(int no) {
		int count=0;
		count=jt.update(DELETE_QRY, no);
		return count;
	}

	@Override
	public int fetchEmployeeNo() {
		int sno=0;
		//Use template
		sno=jt.queryForObject(FIND_EMPNO, Integer.class);
		return sno;
	}
	
	class MyResultSetExtractor implements ResultSetExtractor<List<EmployeeBO>>{

		@Override
		public List<EmployeeBO> extractData(ResultSet rs) throws SQLException,
				DataAccessException {
			List<EmployeeBO> listbo=new ArrayList<EmployeeBO>();
			
			while(rs.next()){
				
				EmployeeBO bo=new EmployeeBO();
				bo.setEmpid(rs.getInt(1));
				bo.setEmpname(rs.getString(2));
				bo.setEmpsalary(rs.getInt(3));
				bo.setStatus(rs.getString(4));
				listbo.add(bo);
			}
			//System.out.println("ResultSetExtractor:"+listbo.size());
			return listbo;
		}
	}

}
