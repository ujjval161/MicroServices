package com.nareshit.service;

public interface UserService {

	String searchUser(Integer userId);

}
