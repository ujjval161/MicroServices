package com.nt.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.nt.bo.EmployeeBO;

public class EmployeeDAOImpl implements EmployeeDAO {
	//prepare Query
	private static final String GET_EMP_LIST="SELECT EMPNO,EMPNAME,SALARY FROM EMPLOYEE";
	private JdbcTemplate jt;

	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}

	@Override
	public List<EmployeeBO> getEmpList() {
		List<EmployeeBO> listbo=null;
		// Use jt
		listbo=jt.query(GET_EMP_LIST, rs->{
			List<EmployeeBO> listebo=null;
			EmployeeBO bo=null;
			listebo=new ArrayList<EmployeeBO>();
			while(rs.next()) {
				bo=new EmployeeBO();
				bo.setEmpno(rs.getInt(1));
				bo.setEmpname(rs.getString(2));
				bo.setSalary(rs.getDouble(3));
				listebo.add(bo);
			}//while
			return listebo;
		});
		return listbo;
	}

}
