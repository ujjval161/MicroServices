package com.nt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;

import com.nt.bo.EmployeeBO;
import com.nt.dao.EmployeeDAO;
import com.nt.dto.EmployeeDTO;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDAO dao;
	public void setDao(EmployeeDAO dao) {
		this.dao = dao;
	}
	@Override
	public List<EmployeeDTO> findEmpList() {
		List<EmployeeDTO> listdto=null;
		List<EmployeeBO> listbo=null;
		EmployeeDTO dto=null;
		// Use dao
		listbo=dao.getEmpList();
		//convert listbo to listdto
		listdto=new ArrayList<>();
		for(EmployeeBO bo:listbo) {
			dto=new EmployeeDTO();
			BeanUtils.copyProperties(bo, dto);
			listdto.add(dto);
		}
		return listdto;
	}

}
