package com.nt.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.nt.dto.EmployeeDTO;
import com.nt.service.EmployeeService;

public class EmployeeListController extends AbstractController {
	private EmployeeService service;

	public void setService(EmployeeService service) {
		this.service = service;
	}


	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		List<EmployeeDTO> listdto=null;
		ModelAndView mav=null;
		//Use service
		listdto=service.findEmpList();
		//create and return mav objet
		mav=new ModelAndView();
		mav.setViewName("employee_list");
		mav.addObject("employeeList", listdto);
		return mav;
	}

}
