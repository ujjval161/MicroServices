package com.nt.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.nt.bo.StudentBO;

public class StudentDAOImpl implements StudentDAO{
	//Prepare Query
	private static final String GET_ALL_STUDENT="SELECT SNO,SNAME,SADD FROM STUDENT";
	private static final String GET_STUDENT_BY_NO="SELECT SNO,SNAME,SADD FROM STUDENT WHERE SNO=?";
	private static final String UPDATE_STUDENT="UPDATE STUDENT SET SNAME=?,SADD=? WHERE SNO=?";
	private static final String INSERT_QRY="INSERT INTO STUDENT VALUES(?,?,?)";
	private static final String DELETE_QRY="DELETE FROM STUDENT WHERE SNO=?";
	private static final String FIND_SNO="SELECT STUDENT_SNO.nextVal FROM DUAL";
	private JdbcTemplate jt;

	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}

	@Override
	public List<StudentBO> studentsDetails() {
		// Use JDBC template
		List<StudentBO> listBO=null;
		listBO=jt.query(GET_ALL_STUDENT, rs->{
			List<StudentBO> listLBO=new ArrayList<StudentBO>();
			StudentBO bo=null;
			while(rs.next()) {
				bo=new StudentBO();
				bo.setSno(rs.getInt(1));
				bo.setSname(rs.getString(2));
				bo.setSadd(rs.getString(3));
				listLBO.add(bo);
			}//while loop
			return listLBO;
		}//Lambda Expression based inner class
		);
		return listBO;
	}

	@Override
	public StudentBO getStudentByNo(int no) {
		StudentBO bo=null;
		// Use jt to interect with db and get result in the form of bo object
		bo=jt.queryForObject(GET_STUDENT_BY_NO, (rs,index)->{
			StudentBO sbo=new StudentBO();
			sbo.setSno(rs.getInt(1));
			sbo.setSname(rs.getString(2));
			sbo.setSadd(rs.getString(3));
			return sbo;
		}, no);
		return bo;
	}

	@Override
	public int UpdateStudentDetails(StudentBO bo) {
		int count=0;
		// Use jt to update Student details
		count=jt.update(UPDATE_STUDENT, bo.getSname(),bo.getSadd(),bo.getSno());
		return count;
	}

	@Override
	public int insertStudent(StudentBO bo) {
		int count=0;
		count=jt.update(INSERT_QRY, bo.getSno(),bo.getSname(),bo.getSadd());
		return count;
	}

	@Override
	public int deleteStudent(int no) {
		int count=0;
		count=jt.update(DELETE_QRY, no);
		return count;
	}

	@Override
	public int fetchStudentNo() {
		int sno=0;
		//Use template
		sno=jt.queryForObject(FIND_SNO, Integer.class);
		return sno;
	}

}
