package com.nt.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.BeanUtils;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.nt.command.StudentCommand;
import com.nt.dto.StudentDTO;
import com.nt.service.StudentService;

@SuppressWarnings("deprecation")
public class StudentRegisterController extends SimpleFormController {
	private StudentService service;

	public void setService(StudentService service) {
		this.service = service;
	}
	@Override
	public Object formBackingObject(HttpServletRequest request) throws Exception {
		int sno=0;
		StudentCommand cmd=null;
		// Use service to get student no fetched from database sequence
		sno=service.getStudentNumberFormSequence();
		//place student number into command object so that it can display in form page
		cmd=new StudentCommand();
		cmd.setSno(sno);
		return cmd;
	}

	@Override
	public ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
			BindException errors) throws Exception {
		StudentCommand cmd=null;
		ModelAndView mav=null;
		String result=null;
		StudentDTO dto=null;
		//typecasting
		cmd=(StudentCommand)command;
		//convert command object to dto object
		dto=new StudentDTO();
		BeanUtils.copyProperties(cmd, dto);
		result=service.registerStudent(dto);
		//create and return mav object
		mav=new ModelAndView();
		mav.setViewName("register_result");
		mav.addObject("register_student", result);
		return mav;
	}

}
