package com.nt.controller;

//import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.BeanUtils;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.nt.command.StudentCommand;
import com.nt.dto.StudentDTO;
import com.nt.service.StudentService;

@SuppressWarnings("deprecation")
public class StudentEditController extends SimpleFormController {
	private StudentService service;

	public void setService(StudentService service) {
		this.service = service;
	}
	
	@Override
	public Object formBackingObject(HttpServletRequest request) throws Exception {
		int sno=0;
		StudentDTO dto=null;
		StudentCommand cmd=null;
		//read sno
		sno=Integer.parseInt(request.getParameter("sno"));
		//Use service class
		dto=new StudentDTO();
		dto=service.fetchStudentByNo(sno);
		cmd=new StudentCommand();
		BeanUtils.copyProperties(dto,cmd);
		return cmd;
	}
	
	@Override
	public ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
			BindException errors) throws Exception {
		String result=null;
		StudentCommand cmd=null;
		StudentDTO dto=null;
		ModelAndView mav=null;
		//List<StudentDTO> listdto=null;
		// type cast 
		cmd=(StudentCommand)command;
		//convert command object into student dto
		dto=new StudentDTO();
		BeanUtils.copyProperties(cmd,dto);
		//use service 
		//listdto=service.fetchStudents();
		result=service.updateStudent(dto);
		//create and return ModelAndView Object
		mav=new ModelAndView();
		mav.setViewName("edit_result");
		//mav.addObject("stList",listdto);
		mav.addObject("edit_result",result);
		return mav;
	}//onSubmit()
}//class
