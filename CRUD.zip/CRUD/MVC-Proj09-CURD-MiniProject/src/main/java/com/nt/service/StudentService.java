package com.nt.service;

import java.util.List;

import com.nt.dto.StudentDTO;

public interface StudentService {
	public List<StudentDTO> fetchStudents();
	public StudentDTO fetchStudentByNo(int no);
	public String updateStudent(StudentDTO dto);
	public String registerStudent(StudentDTO dto);
	public String eraseStudentDetails(int no);
	public int getStudentNumberFormSequence();
}
