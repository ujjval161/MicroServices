package com.nt.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.BeanUtils;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.nt.command.StudentCommand;
import com.nt.dto.StudentDTO;
import com.nt.service.StudentService;

@SuppressWarnings("deprecation")
public class StudentDeleteController extends SimpleFormController {
	private StudentService service;

	public void setService(StudentService service) {
		this.service = service;
	}
	
	@Override
	public Object formBackingObject(HttpServletRequest request) throws Exception {
		StudentCommand cmd=null;
		StudentDTO dto=null;
		int sno=0;
		sno=Integer.parseInt(request.getParameter("sno"));
		//fetch result from db based on sno and place to command object
		dto=service.fetchStudentByNo(sno);
		//copy dto details to command object
		cmd=new StudentCommand();
		BeanUtils.copyProperties(dto, cmd);
		return cmd;
	}//formBackingObject(-)
	
	@Override
	public ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
			BindException errors) throws Exception {
		ModelAndView mav=null;
		StudentCommand cmd=null;
		String result=null;
		int sno=0;
		//type casting
		cmd=(StudentCommand)command;
		sno=cmd.getSno();
		//use service
		result=service.eraseStudentDetails(sno);
		//create and return mav object
		mav=new ModelAndView();
		mav.setViewName("delete_result");
		mav.addObject("delete_student", result);
		return mav;
		
		
	}

}
