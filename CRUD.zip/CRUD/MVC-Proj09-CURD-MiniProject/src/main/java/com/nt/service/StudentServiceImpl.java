package com.nt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;

import com.nt.bo.StudentBO;
import com.nt.dao.StudentDAO;
import com.nt.dto.StudentDTO;

public class StudentServiceImpl implements StudentService {
	private StudentDAO dao;

	public void setDao(StudentDAO dao) {
		this.dao = dao;
	}

	@Override
	public List<StudentDTO> fetchStudents() {
		List<StudentBO> listbo=null;
		List<StudentDTO> listdto=null;
		StudentDTO dto=null;
		// Use dao
		listbo=dao.studentsDetails();
		//convert studentBO to StudentDTO
		listdto=new ArrayList<StudentDTO>();
		for(StudentBO bo:listbo) {
			dto=new StudentDTO();
			BeanUtils.copyProperties(bo, dto);
			listdto.add(dto);
		}
		return listdto;
	}

	@Override
	public StudentDTO fetchStudentByNo(int no) {
		StudentDTO dto=null;
		StudentBO bo=null;
		// Use DAO
		bo=dao.getStudentByNo(no);
		//convert bo to dto
		dto=new StudentDTO();
		BeanUtils.copyProperties(bo, dto);
		return dto;
	}

	@Override
	public String updateStudent(StudentDTO dto) {
		int count=0;
		StudentBO bo=null;
		// Convert Student dto to Student bo
		bo=new StudentBO();
		BeanUtils.copyProperties(dto, bo);
		//use dao to update student details
		count=dao.UpdateStudentDetails(bo);
		if(count==0) {
			return "Student Record Cannot Be Updated..";
		}
		else {
			return "Student Record Updated Successfully..";
		}
	}

	@Override
	public String registerStudent(StudentDTO dto) {
		int count=0;
		StudentBO bo=null;
		// Convert Student dto to Student bo
		bo=new StudentBO();
		BeanUtils.copyProperties(dto, bo);
		//use dao to update student details
		count=dao.insertStudent(bo);
		if(count==0) {
			return "Student Record Cannot Be Inserted..!!Try Again";
		}
		else {
			return "Student Record Inserted Successfully..@@";
		}
	}

	@Override
	public String eraseStudentDetails(int no) {
		int count=0;
		//use dao
		count=dao.deleteStudent(no);
		if(count==0)
			return "Student Number:"+no+" not is deleted!!Try Again";
		else
			return "Student Number:"+no+"  is deleted successfully@@";
	}

	@Override
	public int getStudentNumberFormSequence() {
		int sno=0;
		// Use dao
		sno=dao.fetchStudentNo();
		return sno;
	}

}
