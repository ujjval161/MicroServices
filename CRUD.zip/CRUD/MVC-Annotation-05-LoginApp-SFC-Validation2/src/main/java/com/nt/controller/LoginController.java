package com.nt.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nt.command.UserCommand;
import com.nt.dto.UserDTO;
import com.nt.service.UserService;

@Controller
public class LoginController {
	
	@Autowired
	private UserService service;
	
	
	/*@RequestMapping(value="/login.htm")
	public String process(Map<String,Object> map) {
		UserCommand cmd=null;
		cmd=new UserCommand();
		//keep command object into map as model attribute name and value
		map.put("userCmd", cmd);
		//return logical view name
		return "login";
	}*/
	
	//handling initial phase request
	@RequestMapping(value="/login.htm")
	public String process_initial_Phase(Map<String,Object> map,
						@ModelAttribute("userCmd") UserCommand cmd) {
		//return logical view name
		return "login";
	}//process_initial_Phase(-,-)
	
    //handling post back request 
	@RequestMapping(value="/login.htm", method=RequestMethod.POST)
	public String process_post_back(Map<String,Object> map,
						@Valid @ModelAttribute("userCmd") UserCommand cmd,BindingResult errors) {
		UserDTO dto=null;
		String result=null;
		//Convert command object into UserDTO object
		dto=new UserDTO();
		BeanUtils.copyProperties(cmd, dto);
		//Use service
		result=service.authenticateUser(dto);
		//keep result in map as model attribute and value
		map.put("result", result);
		map.put("cmdData", cmd);
		return "login";
	}//process_post_back(-,-,-,-)
	
	//Below code is alternate to referenceData() method of XML based Spring MVC Simple form controller
	
	@ModelAttribute("dmnList")
	public List<String> populateDomain(){
		List<String> domains=null;
		domains=new ArrayList<>();
		domains.add("Gmail");domains.add("Yahoo");domains.add("Rediff");
		return domains;
	}//populateDomain()
	
/*	Built in property editors can able to convert form given String value to
	required command class property.
	But there is some cases where custom property editors cannot convert
	form value to appropriate type.
	ex-if we want to store date value in indian style like(dd-MM-yyyy)
	In such case below given annotation based method is great .
	*/
	
	@InitBinder
	public void myInitBinder(WebDataBinder binder) {
		SimpleDateFormat sdf=null;
		sdf=new SimpleDateFormat("dd-MM-yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}//myInitBinder(-)

}
