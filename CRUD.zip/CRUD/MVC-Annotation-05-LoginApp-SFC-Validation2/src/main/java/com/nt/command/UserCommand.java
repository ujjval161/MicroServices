package com.nt.command;

import java.util.Arrays;
import java.util.Date;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class UserCommand {
	@NotEmpty
	private String username;
	@NotEmpty @Size
	private String password;
	@NotEmpty
	private String domains[];
	@Range(min=1,max=100)
	private Integer age;
	private Date dob;
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}

	public String[] getDomains() {
		return domains;
	}
	public void setDomains(String[] domains) {
		this.domains = domains;
	}
	@Override
	public String toString() {
		return "UserCommand [username=" + username + ", password=" + password + ", domains=" + Arrays.toString(domains)
				+ ", age=" + age + ", dob=" + dob + "]";
	}

	
	
}
