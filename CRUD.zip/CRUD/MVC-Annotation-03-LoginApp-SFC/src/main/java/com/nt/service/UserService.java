package com.nt.service;

import com.nt.dto.UserDTO;

public interface UserService {
	public String authenticateUser(UserDTO dto);

}
