package com.nt.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.bo.UserBO;
import com.nt.dao.UserListDAO;
import com.nt.dto.UserDTO;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserListDAO dao;
	@Override
	public String authenticateUser(UserDTO dto) {
		int count=0;
		UserBO bo=null;
		//Convert UserDTO to UserBO
		bo=new UserBO();
		BeanUtils.copyProperties(dto, bo);
		//use dao
		count=dao.validateUser(bo);
		if(count==0)
		    return "!!!...Invalid User...!!!";
		else
			return "@@@...User is Authorized...@@@";
	}

}
