package com.nt.dao;

import com.nt.bo.UserBO;

public interface UserListDAO {
	public int validateUser(UserBO bo);

}
