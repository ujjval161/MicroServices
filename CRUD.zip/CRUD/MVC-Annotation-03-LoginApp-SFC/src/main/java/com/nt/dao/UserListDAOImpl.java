package com.nt.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nt.bo.UserBO;

@Repository
public class UserListDAOImpl implements UserListDAO {
	//prepare query
	private static final String AUTH_QRY="SELECT COUNT(*) FROM USERLIST WHERE UNAME=? AND PWD=?";
	@Autowired
	private JdbcTemplate jt;
	
	@Override
	public int validateUser(UserBO bo) {
		int count=0;
		//Use jt
		count=jt.queryForObject(AUTH_QRY, Integer.class, bo.getUsername(),bo.getPassword());
		return count;
	}

}
